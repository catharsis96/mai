﻿using System;

namespace AppForPresentation_8._11._16_
{
    //struct MyTypeOfVariable
    //{
    //    public int Num;
    //    public string ID;
    //}
    public class Program
    {
        public static void Main(string[] args)
        {
            #region Основные типы переменных

            int x = 54;   //целочисленные
        
            double y = 43.6; //с плавающей точкой

            bool nBool = true; //логическая 

            string str = "Новая строка"; //строковая

            DateTime time = new DateTime(16,11,30); // временной тип

            //MyTypeOfVariable

            #endregion

            #region Объявление нового типа с конструктором без параметров 

            NewClassForEx thisClass = new NewClassForEx();

            thisClass.PublicInt = -1;
            thisClass.IncLockalVar();

            //Console.WriteLine(thisClass.PublicInt);

            for (int i = 0; i < 10; i++)
            {
                thisClass.IncLockalVar();
            }

            //Console.WriteLine(thisClass.PublicInt);

            #endregion

            #region Объявление нового типа с явным конструктором 

            Student stud = new Student("Василий",21,"Прикладная математика и физика",4);
            stud.FaqName = null;

            //string[] newres = stud.FaqName.Split();

            //Console.WriteLine(stud.FaqName);

            #endregion

            #region Перегрузка метода 

            //NewClassForEx -> ChangePrivate c сигнатурой (string), ChangePrivate с сигнатурой (int)

            #endregion

            #region Простое наследование классов ( с неявным конструктором) 

            //ChildOfNewClassForEx

            #endregion

            #region Наследование классов с явным конструктором (наследование конструктора) 

            //Nerd

            #endregion

        }
    }

    #region Дополнительные классы
    internal class ChildOfNewClassForEx : NewClassForEx
    {
        public void NewMethod()
        {
            PublicInt = 10;

            int k = PublicInt;
            IncLockalVar();

            int m = PublicInt;
        }
    }
    public class Nerd : Student
    {
        public Nerd(string name, int age, string faqName = "", int course = 2)
            : base(name, age, faqName, course)
        {

        }

        public void ChangeFaq(string nextFaq)
        {
            this.FaqName = nextFaq;
        }
    }
    public class Student
    {
        private string _name;
        private int _age;
        private int _course;
        private string _faqName;

        public string Name
        {
            get
            {
                return _name;
            }

            set
            {
                if (!string.IsNullOrWhiteSpace(value))
                {
                    _name = value;
                }
            }
        }
        public int Age
        {
            get
            {
                return _age;
            }

            set
            {
                if (value > 0 && value < 130) _age = value;
            }
        }
        public int Course
        {
            get
            {
                return _course;
            }

            set
            {
                if (value > 0 && value <= 6) _course = value;
            }
        }
        public string FaqName
        {
            get
            {
                return _faqName;
            }

            set
            {
                /*if (!string.IsNullOrWhiteSpace(value))
                {
                    _faqName = value;
                }
                */
                _faqName = value;
            }
        }
        public Student(string name, int age, string faqName = "", int course = 1)
        {
            _name = name;
            _age = age;
            _course = course;
            _faqName = faqName;
        }
    }
    internal class NewClassForEx
    {
        private int _privateInt;

        public int PublicInt
        {
            get { return _privateInt; }
            set
            {
                if (value > 0)
                {
                    _privateInt = value;
                }
            }
        }

        public void IncLockalVar()
        {
            _privateInt++;
        }

        public void ChangePrivate(string strNum)
        {
            var isNum = int.TryParse(strNum,out _privateInt);
            if (!isNum)
            {
                string ex = string.Format("Неудачное преобразование '{0}' в число", strNum);
                throw new Exception(ex);
            }
        }
        public void ChangePrivate(int num)
        {
            if (num > 0)
            {
                _privateInt = num;
            }
        }
    }
    #endregion
}
